class AccountCouponcode < ActiveRecord::Base
	belongs_to :account
end
